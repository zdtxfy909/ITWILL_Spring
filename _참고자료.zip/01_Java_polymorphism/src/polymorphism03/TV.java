package polymorphism03;

public interface TV {
	public void powerOn(); //정의만 한다
	public void powerOff();
	public void volumeUp();
	public void volumeDown();
}
